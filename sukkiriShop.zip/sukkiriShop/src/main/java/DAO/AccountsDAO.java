package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Account;
import model.Login;

public class AccountsDAO {
	private final String DB_URL = "jdbc:h2:tcp://localhost/~/sukkiriShop";
	private final String DB_USER = "sa";
	private final String DB_PASS = "";
	
	public Account findByLogin (Login login) {
		
		Account account = null;
		
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			throw new IllegalAccessError();
		}
		
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT * FROM ACCOUNTS WHERE USER_ID = ? AND PASS = ?"; 
			
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, login.getUserId());
			statement.setString(2, login.getPass());
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()) {
				String userId = rs.getString("USER_ID");
				String pass = rs.getString("PASS");
				String mail = rs.getString("MAIL");
				String name = rs.getString("NAME");
				int age = rs.getInt("AGE");
				
				account = new Account(userId, pass, mail, name, age);
			}
		} catch (SQLException e) {
			e.getErrorCode();
			return null;
		}
		
		return account;
	}
	
	public boolean createByLogin (Account account) {
		
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			throw new IllegalAccessError();
		}
		
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
			String sql = "INSERT INTO ACCOUNTS VALUES(?,?,?,?,?)"; 
			
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, account.getUserId());
			statement.setString(2, account.getPass());
			statement.setString(3, account.getMail());
			statement.setString(4, account.getName());
			statement.setInt(5, account.getAge());
			
			int result = statement.executeUpdate();
			
			if (result != 1) {
				return false;
			}
			
			
		} catch (SQLException e) {
			e.getErrorCode();
			return false;
		}
		
		return true;

		
	}
	
	public boolean deleteByAccount (Login login) {
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			throw new IllegalAccessError();
		}
		
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
			String sql = "DELETE FROM ACCOUNTS WHERE USER_ID = ? AND PASS = ?";
			
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, login.getUserId());
			statement.setString(2, login.getPass());
			
			int result = statement.executeUpdate();
			
			if (result != 1) {
				return false;
			}
			
			
		} catch (SQLException e) {
			e.getErrorCode();
			System.out.println(e.getMessage());
			return false;
		}
		
		return true;
	}
}
