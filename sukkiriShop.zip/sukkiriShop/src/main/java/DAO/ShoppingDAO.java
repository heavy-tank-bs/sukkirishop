package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Shopping;

public class ShoppingDAO {
	private final String DB_URL = "jdbc:h2:tcp://localhost/~/sukkiriShop";
	private final String DB_USER = "sa";
	private final String DB_PASS = "";
	
	public List<Shopping> findAll() {
		
		List<Shopping> shoppingList = new ArrayList<>();
		
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException("JDBCドライバを読み込めませんでした");
		}
		
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT * FROM SHOPPING";
			PreparedStatement statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()) {
				String productName = rs.getString("PRODUCT_NAME");
				int price = rs.getInt("PRICE");
				
				Shopping shopping = new Shopping(productName, price);
				shoppingList.add(shopping);
			}
			
			
		} catch (SQLException e) {
			e.getErrorCode();
			System.out.println(e.getMessage());
			return null;
		}
		
		return shoppingList;
	}
}
