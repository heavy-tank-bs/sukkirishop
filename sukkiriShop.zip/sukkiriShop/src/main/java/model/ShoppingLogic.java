package model;

import java.util.List;

import DAO.ShoppingDAO;

public class ShoppingLogic {
	public List<Shopping> execute() {
		ShoppingDAO dao = new ShoppingDAO();
		List<Shopping> shoppingList = dao.findAll();
		return shoppingList;
	}
}
