package model;

import DAO.AccountsDAO;

public class LoginLogic {
	public boolean execute (Login login) {
		AccountsDAO dao = new AccountsDAO();
		Account account = dao.findByLogin(login);
		return account != null;
	}
	
	public boolean create (Account account) {
		AccountsDAO dao = new AccountsDAO();
		return dao.createByLogin(account);
	}
	
	public boolean delete (Login login) {
		AccountsDAO dao = new AccountsDAO();
		return dao.deleteByAccount(login);
	}
}
